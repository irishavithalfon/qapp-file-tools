﻿<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:msxsl="urn:schemas-microsoft-com:xslt" exclude-result-prefixes="msxsl">
	<xsl:output method="html" indent="yes"/>

	<!-- Global Parameters -->
	<!--
    The ThemesFolder Parameter
    Use the ThemesFolder parameter to find the location of the current theme's folder
    Example:

        <xsl:value-of select="$ThemesFolder"/>\Images\Avatar<xsl:value-of select ="/Message/Parameter[@name='AvatarId']"/>.png
    -->
	<xsl:param name="ThemesFolder" />
	<xsl:template match="/">
		<!--<xsl:element name="html">-->
		<xsl:element name="head"></xsl:element>
			<xsl:element name="body">
					<xsl:attribute name="style">
						margin: 0;
						overflow: hidden;
					</xsl:attribute>
				<xsl:element name="div">
						<xsl:attribute name="align">center</xsl:attribute>
						<xsl:attribute name="style">
							width:1920px;
							height:180px;
							background-color:#0d4d8c;
						</xsl:attribute>

					<xsl:element name="div">
							<xsl:attribute name="style">
								width:1920px;
								height:180px;
								font-size:120px;
								font-family:OpenSansHebrew-Regular;
								color:#ffffff;
								font-weight:regular;
								text-align:center;
                direction:rtl;
								line-height:180px;
							</xsl:attribute>
						לקוח <xsl:value-of select ="/Message/Parameter[@name='QCode']"/><xsl:value-of select ="/Message/Parameter[@name='QNumber']"/> ל<xsl:value-of select ="/Message/Parameter[@name='LocationName']"/>
					</xsl:element>
				</xsl:element>
			</xsl:element>
	</xsl:template>
</xsl:stylesheet>
