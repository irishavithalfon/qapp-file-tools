﻿-- =============================================
-- Author:		Mor Hagbi
-- Create date: 17/07/2019
-- Description: Get Personal id from user custom property by key
-- Original Procedure name [cqf].[BusinessLeadManagementUserGetPropertyValueByKey]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementUserGetPropertyValueByKey]
	             @PropertyKey NVARCHAR(50),
				 @UserName NVARCHAR(50)
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		select ucp.PropertyValue   
		from qf.CustomPropertiesDictionary cpd join qf.UserCustomProperty ucp  
			  on cpd.PropertyId = ucp.PropertyId 
			  join qf.Users u on u.UserId = ucp.UserId
		where cpd.PropertyKey = @PropertyKey and u.UserName = @UserName
END
