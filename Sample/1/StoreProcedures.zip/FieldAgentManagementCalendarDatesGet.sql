﻿-- =============================================
-- Author:		<Nativ Dadon>
-- Create date: <25/12/2018>
-- Description:	<Get the dates where calendar is active>
-- Old name: [cqf].[BusinessLeadManagementCalendarDatesGet]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementCalendarDatesGet]
			  @UserId INT
AS
    BEGIN
        SET NOCOUNT ON;
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

        DECLARE @l_daysForward INT= 60, 
				@l_daysBackward INT= 90, 
				@l_duration NUMERIC(6, 2), 
				@l_isDefault BIT

		DECLARE @l_StartDate date,
				@l_EndDate date,
				@l_UserServiceId INT

		DECLARE	@return_value int,
		@PastTimeCalendarStartTime nvarchar(max),
		@PastTimeCalendarEndTime nvarchar(max),
		@Duration numeric(6, 2),
		@IsDefault bit,
		@Argument1 nvarchar(250),
		@Argument2 nvarchar(250),
		@Argument3 nvarchar(250)

		SELECT TOP 1 @l_UserServiceId = ServiceId 
		FROM qf.[Service]
		WHERE CalendarOwnerUserId = @UserId

		SET @l_StartDate = DATEADD(DAY, -@l_daysBackward, GETDATE())
		SET @l_EndDate = DATEADD(DAY, @l_daysForward, GETDATE())

		EXEC	@return_value = [qf].[ContentValueGetByParameterName]
				@ParameterName = N'PastTimeCalendarStartTime',
				@ObjectId = @l_UserServiceId,
				@LanguageCode = N'he',
				@Value = @PastTimeCalendarStartTime OUTPUT,
				@Duration = @Duration OUTPUT,
				@IsDefault = @IsDefault OUTPUT,
				@Argument1 = @Argument1 OUTPUT,
				@Argument2 = @Argument2 OUTPUT,
				@Argument3 = @Argument3 OUTPUT

		EXEC	@return_value = [qf].[ContentValueGetByParameterName]
				@ParameterName = N'PastTimeCalendarEndTime',
				@ObjectId = @l_UserServiceId,
				@LanguageCode = N'he',
				@Value = @PastTimeCalendarEndTime OUTPUT,
				@Duration = @Duration OUTPUT,
				@IsDefault = @IsDefault OUTPUT,
				@Argument1 = @Argument1 OUTPUT,
				@Argument2 = @Argument2 OUTPUT,
				@Argument3 = @Argument3 OUTPUT

        SELECT DISTINCT 
                c.CalendarId, 
                c.[Date], 
                ISNULL(MIN(cs.StartTime),@PastTimeCalendarStartTime) AS 'StartTime', 
                ISNULL(MAX(cs.EndTime),@PastTimeCalendarEndTime) AS 'EndTime'			    
        FROM qf.CalendarAll c
            LEFT JOIN qf.CalendarSegment cs ON cs.CalendarId = c.CalendarId			
            JOIN qf.[Service] s ON c.ServiceId = s.ServiceId and s.CalendarOwnerUserId = @UserId
        WHERE c.[Date] BETWEEN @l_StartDate AND @l_EndDate
             AND c.[Status] = 0
        GROUP BY c.CalendarId, c.[Date]
    END;