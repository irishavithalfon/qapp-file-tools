﻿-- =============================================
-- Update by: Iris
-- Original procedure name: [cqf].[BusinessLeadManagementAppointmentCustomerGet]
-- Description: Removed fields that were not required for the Meitav implementation.
-- Update date: 2026-01
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementAppointmentCustomerGet] 
				@CustomerId INT
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


	SELECT a.AppointmentId,
		   at.AppointmentTypeName,
		   at.Duration,
		   c.DateCreated,
		   p.RecentNotes,
		   cu.CustomerId,
		   cu.FirstName,
		   cu.LastName,	
		   cu.TelNumber1,
		   cu.TelNumber2,
		   cu.PersonalId,
		   p.ProcessId,
		   se.CalendarOwnerUserId,
		   MAX(se.ServiceName) AS 'ServiceName',
		   MAX(a.AppointmentDate) AS 'AppointmentDate',		  
		   MAX(CASE WHEN pcpd.PropertyKey = 'City' THEN pcp.Value END) AS 'City',
		   MAX(CASE WHEN pcpd.PropertyKey = 'Street' THEN pcp.Value END) AS 'Street',
		   MAX(CASE WHEN pcpd.PropertyKey = 'HouseNumber' THEN pcp.Value END) AS 'HouseNumber',
		   MAX(CASE WHEN pcpd.PropertyKey = 'Summary' THEN pcp.Value END) AS 'Summary',
		   MAX(CASE WHEN pcpd.PropertyKey = 'CustomerName' THEN pcp.Value END) AS 'CustomerName',
		   MAX(CASE WHEN pcpd.PropertyKey = 'CustomerPhone' THEN pcp.Value END) AS 'CustomerPhone',
		   CASE WHEN CAST(a.AppointmentDate AS DATE) >= CAST(GETDATE() AS DATE) AND p.CurrentEntityStatus IN (0, 3, 6) THEN 1 ELSE 0 END AS 'IsFutureAppointment',
		   MAX(p.CurrentEntityStatus) AS 'ProcessStatus'
	FROM qf.AppointmentAll a
	JOIN qf.AppointmentType at ON at.AppointmentTypeId = a.AppointmentTypeId
	JOIN qf.ProcessAll p ON p.ProcessId = a.ProcessId
    LEFT JOIN qf.ProcessCustomPropertyAll pcp ON pcp.ProcessId = p.ProcessId
	LEFT JOIN qf.ProcessCustomPropertyDictionary pcpd ON pcpd.PropertyId = pcp.PropertyId 
	JOIN qf.CaseAll c ON c.CaseId = p.CaseId 
	JOIN qf.[Service] se ON se.ServiceId = a.ServiceId
 	JOIN qf.Customer cu ON cu.CustomerId = c.CustomerId AND c.CustomerId = @CustomerId
    JOIN qf.StepAll s ON s.ProcessId = p.ProcessId
	WHERE p.Resolution IS NULL OR NOT p.Resolution = 5 -- Not Rescheduled
	GROUP BY  a.AppointmentId,
			  a.AppointmentDate,
			  a.CancelationReasonId,
			  at.AppointmentTypeName,
			  se.CalendarOwnerUserId,
			  at.Duration,
			  c.DateCreated,
			  p.RecentNotes, 
			  p.ProcessId,
			  cu.PersonalId,
			  cu.FirstName,
			  cu.LastName,
			  cu.TelNumber1,
			  cu.TelNumber2,
			  cu.CustomerId,
			  p.CurrentEntityStatus
			  
	ORDER BY a.AppointmentDate DESC

END