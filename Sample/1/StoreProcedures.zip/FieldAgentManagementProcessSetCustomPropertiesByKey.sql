﻿
/*
 Return Codes:
  55009	: Invalid user name was specified for the 'Invoked By' parameter
  58782: Invalid property name
  
 Created Oct. 2017, v6.1 ssp1
 Created By: Netanel
 Old Name: [cqf].[BusinessLeadManagementProcessSetCustomPropertiesByKey]
*/
CREATE PROCEDURE [cqf].[FieldAgentManagementProcessSetCustomPropertiesByKey]
	@ProcessId INT,
    @Properties XML
AS
	
	SET NOCOUNT ON;
	SET XACT_ABORT ON;

	DECLARE @l_PropertyId INT
	DECLARE @l_PropertyValue NVARCHAR (500)
	DECLARE @l_PropertyKey NVARCHAR (500)

		DECLARE cProperties CURSOR READ_ONLY FORWARD_ONLY FOR
		
		SELECT

               T.c.value('@keyid','nvarchar(500)') as [key],
		       T.c.value('@value','nvarchar(500)') as value
	    FROM  @Properties.nodes('Root/Property') as T(c)
	    
	    OPEN cProperties 

		FETCH FROM cProperties INTO @l_PropertyKey, @l_PropertyValue
			WHILE @@FETCH_STATUS = 0
				BEGIN

				SELECT @l_PropertyId  = PropertyId
	            FROM qf.ProcessCustomPropertyDictionary WITH (NOLOCK)
	            WHERE PropertyKey = @l_PropertyKey

				UPDATE qf.ProcessCustomProperty
		        SET Value = @l_PropertyValue
		        WHERE  ProcessId = @ProcessId
			           AND PropertyId = @l_PropertyId
		
		IF @@ROWCOUNT = 0
			INSERT INTO qf.ProcessCustomProperty(
				ProcessId,
				PropertyId,
				Value)
			VALUES (
				@ProcessId,
				@l_PropertyId, 
				@l_PropertyValue)

				FETCH FROM cProperties INTO @l_PropertyKey, @l_PropertyValue
		END

			
				 CLOSE cProperties

		         DEALLOCATE cProperties
