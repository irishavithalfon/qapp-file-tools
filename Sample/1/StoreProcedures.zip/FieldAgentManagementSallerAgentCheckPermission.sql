﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Original name:	[cqf].[BusinessLeadManagementSallerAgentCheckPermission]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementSallerAgentCheckPermission]
				@CustomerId INT
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    SELECT a.AppointmentId
	FROM qf.AppointmentAll a 
	JOIN qf.ProcessAll p ON p.ProcessId = a.ProcessId
	JOIN qf.CaseAll ca ON ca.CaseId = p.CaseId
	JOIN qf.Customer c ON c.CustomerId = ca.CustomerId
	WHERE a.AppointmentDate BETWEEN CAST(GETDATE()-3 AS DATETIME) AND CAST(GETDATE() AS DATETIME)
	AND c.CustomerId = @CustomerId
	AND p.CurrentEntityStatus = 8 OR p.CurrentEntityStatus = 0

END
