﻿-- =============================================
-- Author:		Mor Hagbi
-- Create date: 07/04/2019
-- Description:	Get Service Id By the Calendar owner user id
-- Original procedure name: [cqf].[BusinessLeadManagementServiceIdGetByCalendarOwnerUserId]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementServiceIdGetByCalendarOwnerUserId]
                 @UserId INT
AS
BEGIN

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  
		select s.ServiceId
		from qf.[Service] s join qf.Users u on u.UserId = s.CalendarOwnerUserId
		where u.UserId = @UserId and s.IsActive = 1
END
