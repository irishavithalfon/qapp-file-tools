﻿
-- =============================================
-- Author:		<Nativ Dadon>
-- Create date: <27/03/2019>
-- Description:	<Returns the Id of the user who created the appointment>
-- Update: [cqf].[BusinessLeadManagementAppointmentGetCreatorId]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementAppointmentGetCreatorId]
				@ProcessId INT
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    SELECT s.UserId
	FROM qf.Step s
	WHERE s.ProcessId = @ProcessId AND s.[Action] = 13

END
