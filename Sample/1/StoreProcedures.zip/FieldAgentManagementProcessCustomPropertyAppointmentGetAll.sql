﻿-- =============================================
-- Author:		Mor Hagbi
-- Create date: 04/02/2019
-- Description:	Get all pcp for set appointment
-- Update by: Iris
-- Original procedure name: [cqf].[BusinessLeadManagementProcessCustomPropertyAppointmentGetAll]
-- Description: Removed pcps that were not required for the Meitav implementation.
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementProcessCustomPropertyAppointmentGetAll]
	
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	SELECT pcpd.PropertyName,
		   pcpd.Argument1,
		   pcpd.Argument2,
		   pcpd.Argument3,
		   pcpd.ValueType,
		   pcpd.ValidationExpression, 
		   pcpd.PropertyKey,
		   pcpd.IsReadOnly,
		   pcpd.PropertyId
	FROM   qf.ProcessCustomPropertyDictionary pcpd 
	WHERE pcpd.PropertyKey IN('City' , 'Street' , 'HouseNumber', 'CustomerName', 'CustomerPhone') 
	ORDER BY pcpd.Position

END

