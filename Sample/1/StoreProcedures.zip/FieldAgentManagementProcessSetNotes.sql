﻿-- =============================================
-- Author:		Mor Hagbi
-- Create date: 01/01/2019
-- Description:	Update the recent noted field in the process 
-- Original procedure name: [cqf].[BusinessLeadManagementProcessSetNotes]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementProcessSetNotes] 
                  @ProcessId INT, 
				  @RecentNotes NVARCHAR(4000)
AS
BEGIN
    SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
			UPDATE qf.process
			SET RecentNotes = @RecentNotes
			WHERE ProcessId = @ProcessId
END

