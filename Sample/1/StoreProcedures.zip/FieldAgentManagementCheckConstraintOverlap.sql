-- =============================================
-- Author:  	Yonatan Ziv
-- Create date: 21/03/2021
-- Description:	Procedure that checks if a constraint overlaps with another constraint or appointment

-- Note: This procedure is used by the FieldAgentManagement site.
-- Last update: 27/07/2025 - Added the OverlapSource column and changed the return to include full overlap data.
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementCheckConstraintOverlap] 
	@UnitId int,
	@Date datetime,
	@Duration int,
	@CustomerId int
AS
BEGIN


  -- Search for overlaps with Constraints
  SELECT
    Id,
    ConstraintDate AS [Date],
    Duration,
    CustomerId,
    UnitId,
    Reason,
	'CustomerConstraintOverlap' AS OverlapSource
  FROM cqf.CustomerConstraints
  WHERE CustomerId = @customerId
  AND UnitId = @unitId
  AND ((@Date > ConstraintDate
  AND @Date < DATEADD(MINUTE, Duration, ConstraintDate))
  OR (DATEADD(MINUTE, @duration, @Date) > ConstraintDate
  AND DATEADD(MINUTE, @duration, @Date) < DATEADD(MINUTE, Duration, ConstraintDate))
  OR (ConstraintDate > @Date
  AND ConstraintDate < DATEADD(MINUTE, @duration, @Date))
  OR (DATEADD(MINUTE, Duration, ConstraintDate) > @Date
  AND DATEADD(MINUTE, Duration, ConstraintDate) < DATEADD(MINUTE, @duration, @Date)))

  UNION

  -- Search for overlaps with Appointments (Normal)
  SELECT
    AppointmentId AS Id,
    AppointmentDate AS [Date],
    AppointmentDuration AS Duration,
    c.CustomerId,
    s.UnitId,
    '' AS Reason,
	'CustomerAppointmentOverlap' AS OverlapSource
  FROM qf.Appointment a
  JOIN qf.Process p
    ON p.ProcessId = a.ProcessId
  JOIN qf.[Case] c
    ON c.CaseId = p.CaseId
  JOIN qf.Service s
    ON s.ServiceId = p.CurrentServiceId
  WHERE c.CustomerId = @customerId
  AND UnitId = @unitId
  AND (p.CurrentEntitystatus = 0
  OR p.CurrentEntitystatus = 3
  OR p.CurrentEntitystatus = 6
  OR p.CurrentEntitystatus = 10
  OR p.CurrentEntitystatus = 11
  OR p.CurrentEntitystatus = 20)
  AND (
  (@Date > a.AppointmentDate
  AND @Date < DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate))
  OR (DATEADD(MINUTE, @duration, @Date) > a.AppointmentDate
  AND DATEADD(MINUTE, @duration, @Date) < DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate))
  OR (a.AppointmentDate > @Date
  AND a.AppointmentDate < DATEADD(MINUTE, @duration, @Date))
  OR (DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate) < @Date
  AND DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate) > DATEADD(MINUTE, @duration, @Date))
  )

  UNION

  -- Search for overlaps with Appointments (Customer Group)
  SELECT
    a.AppointmentId AS Id,
    a.AppointmentDate AS [Date],
    a.AppointmentDuration AS Duration,
    cc.CustomerId,
    s.UnitId,
    '' AS Reason,
	'CustomerGroupAppointmentOverlap' AS OverlapSource
  FROM qf.Appointment a
  JOIN qf.Process p
    ON a.ProcessId = p.ProcessId
  JOIN qf.[Case] cas
    ON cas.CaseId = p.CaseId
  JOIN qf.Customer c
    ON c.CustomerId = cas.CustomerId
  JOIN qf.CustomerGroupCustomer cgc
    ON cgc.CustomerGroupId = c.CustomerId
  JOIN qf.Service s
    ON s.ServiceId = a.ServiceId
  JOIN qf.CaseCustomer cc
    ON cc.CaseId = cas.CaseId
    AND cc.CustomerId = cgc.CustomerId
  WHERE c.IsCustomerGroup = 'true'
  AND cc.CustomerId = @customerId
  AND (s.UnitId = @UnitId
  AND (CurrentEntitystatus = 0
  OR CurrentEntitystatus = 3
  OR CurrentEntitystatus = 6
  OR CurrentEntitystatus = 10
  OR CurrentEntitystatus = 11
  OR CurrentEntitystatus = 20))
  AND (
  (@Date < a.AppointmentDate
  AND @Date > DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate))
  OR (DATEADD(MINUTE, @duration, @Date) < a.AppointmentDate
  AND DATEADD(MINUTE, @duration, @Date) > DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate))
  OR (a.AppointmentDate < @Date
  AND a.AppointmentDate > DATEADD(MINUTE, @duration, @Date))
  OR (DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate) < @Date
  AND DATEADD(MINUTE, AppointmentDuration, a.AppointmentDate) > DATEADD(MINUTE, @duration, @Date))
  )
END