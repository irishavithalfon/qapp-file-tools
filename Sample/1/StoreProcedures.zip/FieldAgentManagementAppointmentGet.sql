﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Update:    Removed logic that was not required for the Meitav implementation.
-- Old name: [cqf].[BusinessLeadManagementAppointmentGet]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementAppointmentGet]
			   @ProcessId INT
AS

    BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
        SELECT a.AppointmentId, 
		       at.AppointmentTypeId,
               at.AppointmentTypeName, 
               at.Duration, 
               c.DateCreated, 
               p.RecentNotes, 
               cu.CustomerId, 
               cu.FirstName, 
               cu.LastName, 
               cu.TelNumber1, 
               cu.TelNumber2, 
               cu.PersonalId, 
               p.ProcessId, 
			   MAX(se.ServiceId) AS 'ServiceId',   
               MAX(se.ServiceName) AS 'ServiceName', 
               MAX(a.AppointmentDate) AS 'AppointmentDate', 
               MAX(p.RecentNotes) AS 'RecentNotes', 
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'City'
                       THEN pcp.Value
                   END) AS 'City', 
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'Street'
                       THEN pcp.Value
                   END) AS 'Street', 
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'HouseNumber'
                       THEN pcp.Value
                   END) AS 'HouseNumber', 
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'Summary'
                       THEN pcp.Value
                   END) AS 'Summary',
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'CustomerName'
                       THEN pcp.Value
                   END) AS 'CustomerName',
               MAX(CASE
                       WHEN pcpd.PropertyKey = 'CustomerPhone'
                       THEN pcp.Value
                   END) AS 'CustomerPhone',
               CASE
                   WHEN a.AppointmentDate > GETDATE()
                   THEN 1
                   ELSE 0
               END AS 'IsFutureAppointment', 
               MAX(p.CurrentEntityStatus) AS 'ProcessStatus'
        FROM qf.AppointmentAll a
             JOIN qf.AppointmentType AT ON at.AppointmentTypeId = a.AppointmentTypeId
             JOIN qf.ProcessAll p ON p.ProcessId = a.ProcessId
             LEFT JOIN qf.ProcessCustomProperty pcp ON pcp.ProcessId = p.ProcessId
             LEFT JOIN qf.ProcessCustomPropertyDictionary pcpd ON pcpd.PropertyId = pcp.PropertyId
             JOIN qf.CaseAll c ON c.CaseId = p.CaseId
             JOIN qf.[Service] se ON se.ServiceId = a.ServiceId
             JOIN qf.Customer cu ON cu.CustomerId = c.CustomerId
             JOIN qf.CustomerCustomProperty ccp ON ccp.CustomerId = cu.CustomerId
             JOIN qf.CustomPropertiesDictionary cpd ON cpd.PropertyId = ccp.PropertyId
             JOIN qf.StepAll s ON s.ProcessId = p.ProcessId
             JOIN qf.Users u ON u.UserId = c.CreatedBy
             LEFT JOIN qf.AppointmentCancelationReason acr ON acr.CancelationReasonId = a.CancelationReasonId
        WHERE p.ProcessId = @ProcessId
        GROUP BY a.AppointmentId, 
                 a.AppointmentDate, 
                 a.CancelationReasonId, 
				 at.AppointmentTypeId,
                 at.AppointmentTypeName, 
                 at.Duration, 
                 c.DateCreated, 
                 p.RecentNotes, 
                 p.ProcessId, 
				 se.ServiceId,
                 cu.PersonalId, 
                 cu.FirstName, 
                 cu.LastName, 
                 cu.TelNumber1, 
                 cu.TelNumber2, 
                 cu.CustomerId
        ORDER BY a.AppointmentDate DESC;
    END;
