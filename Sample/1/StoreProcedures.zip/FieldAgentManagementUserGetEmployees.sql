﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Original Procedure name:	[cqf].[BusinessLeadManagementUserGetEmployees]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementUserGetEmployees] 
				@UserName NVARCHAR(50)
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


    SELECT u.FirstName , u.LastName 
	FROM qf.Users u
	where u.UserName = @UserName

	SELECT u.UserName,u.FirstName,u.LastName, u.UserId 'AgentUserId'
	FROM qf.Users u
	JOIN qf.UserCustomProperty ucp ON ucp.UserId = u.UserId AND ucp.PropertyValue = @UserName
	JOIN qf.CustomPropertiesDictionary cpd ON cpd.ExtRef = 'ManagerUserName' 

   
END
