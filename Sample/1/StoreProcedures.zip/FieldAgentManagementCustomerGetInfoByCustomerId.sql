﻿-- =============================================
-- Author:      <Naitv Dadon>
-- Create date: <16/12/2018>
-- Description: <Return customer details>
-- Update by:       Iris
--              Meitav changes:
--              1) Removed GroupName and LeadCreator -> Users -> Groups logic
--              2) Removed CustomerLevelList section (AllowedCustomerLevel) entirely
--              3) CCP list was updated by the user separately
--				4) The orignal name was [cqf].[BusinessLeadManagementCustomerGetInfoByCustomerId]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementCustomerGetInfoByCustomerId]
    @CustomerId INT
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    -- 1) Temporary table for CCP result set

    CREATE TABLE #CustomerProperties
    (
        PropertyId      INT,
        PropertyName    NVARCHAR(50),
        PropertyExtref  NVARCHAR(50),
		PropertyKey     NVARCHAR(50),
        PropertyValue   NVARCHAR(200),
        CustomerId      INT
    );


    -- 2) Load  the relevant CCP extrefs (already adjusted by the user)

    INSERT INTO #CustomerProperties (PropertyId, PropertyName, PropertyExtref, PropertyKey, PropertyValue, CustomerId)
    SELECT
        cpd.PropertyId,
        cpd.PropertyName,
        cpd.ExtRef,
		cpd.PropertyKey,
        ccp.PropertyValue,
        ccp.CustomerId
    FROM qf.CustomPropertiesDictionary cpd
    LEFT JOIN qf.CustomerCustomProperty ccp ON cpd.PropertyId = ccp.PropertyId AND ccp.CustomerId = @CustomerId
    WHERE cpd.PropertyKey IN ('CustomerCreatedDate','TownDescription','Street','HouseNo');

    -- Result set #1: Structured customer details (WITHOUT GroupName)

    SELECT
        cu.CustomerId,
        cu.PersonalId,
        cu.FirstName,
        cu.LastName,
        cu.TelNumber1,
        cu.TelNumber2,
        cu.EMail,
        MAX(cu.CustomerIdTypeId) AS CustomerIdTypeId
    FROM qf.Customer cu
    WHERE cu.CustomerId = @CustomerId
    GROUP BY
        cu.CustomerId,
        cu.PersonalId,
        cu.FirstName,
        cu.LastName,
        cu.TelNumber1,
        cu.TelNumber2,
        cu.EMail;

    -- Result set #2: CCP list

    SELECT
        cp.PropertyId,
        cp.PropertyName,
        cp.PropertyValue,
        cp.PropertyExtref,
		cp.PropertyKey
    FROM #CustomerProperties cp;


END
