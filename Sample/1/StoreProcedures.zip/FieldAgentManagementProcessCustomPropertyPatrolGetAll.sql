﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Original Procedure name:	[cqf].[BusinessLeadManagementProcessCustomPropertyPatrolGetAll]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementProcessCustomPropertyPatrolGetAll]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	

	SELECT pcpd.PropertyName,
		   pcpd.Argument1,
		   pcpd.Argument2,
		   pcpd.Argument3,
		   pcpd.ValueType,
		   pcpd.ValidationExpression, 
		   pcpd.PropertyKey		   
	FROM qf.ProcessCustomPropertyDictionary pcpd
	WHERE pcpd.Argument1 = 'Sayeret' AND pcpd.IsActive = 1

END
