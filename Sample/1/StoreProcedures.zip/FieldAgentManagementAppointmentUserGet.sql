﻿-- =============================================
-- Author:		<Nativ Dadon>
-- Create date: <16/12/2018>
-- Description:	<Returns all the appointments of a service by date>
-- Update by Iris: Disabled CustomerLevelName, CreatorGroupExtRef (and removed join to qf.Groups), CustomerBan, and IsFromOutlock.
--                 Related joins/logic remain only where required for other returned fields.
--				   Original name: [cqf].[BusinessLeadManagementAppointmentUserGet]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementAppointmentUserGet]
				@UserId INT,
				@CurrentUserId INT, 
				@CalendarDate DATETIME				
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @l_IsDateInThePast BIT = 0;

	IF (CAST(GETDATE() AS DATE) > CAST(@CalendarDate AS DATE))
	BEGIN
		SET @l_IsDateInThePast = 1;
	END

	--DROP TABLE #AppointmentsTemp
	CREATE TABLE #AppointmentsTemp
	(
		AppointmentId INT,
		AppointmentTypeId INT,
		AppointmentTypeName NVARCHAR(50),
		Duration INT,
		AppointmentTime DATETIME,
		AppointmentCreationDate DATETIME,
		ProcessId INT,
		CaseId INT,
		ProcessStatus INT,
		City NVARCHAR(50),
		Street NVARCHAR(50),
		HouseNumber NVARCHAR(50),
		Summary NVARCHAR(4000),
		CustomerName NVARCHAR(4000),
		RecentNotes NVARCHAR(4000),
		CustomerId INT,
		CustomerFirstName NVARCHAR(50),
		CustomerLastName NVARCHAR(50),
		IsFutureAppointment BIT,
		PersonalId NVARCHAR(50),
		TelNumber1 NVARCHAR(50),
		TelNumber2 NVARCHAR(50),
		[Subject] NVARCHAR(MAX),
		CustomerCreationDate DATETIME,
		CustomerIdTypeId INT,
		CustomerPhone NVARCHAR(255)
	);

	DECLARE @l_SubjectValue NVARCHAR(100), 
            @l_Duration     NUMERIC (6,2),
		    @l_IsDefulte    BIT, 
		    @l_arg1         NVARCHAR(100), 
		    @l_arg2         NVARCHAR(100);

	IF (@l_IsDateInThePast = 1)
	BEGIN
		INSERT INTO #AppointmentsTemp
		(
			AppointmentId,
			AppointmentTypeId,
			AppointmentTypeName,
			Duration,
			AppointmentTime,
			AppointmentCreationDate,
			ProcessId,
			CaseId,
			ProcessStatus,
			City,
			Street,
			HouseNumber,
			Summary,
			CustomerName,
			RecentNotes,
			CustomerId,
			PersonalId,
			CustomerFirstName,
			CustomerLastName,
			IsFutureAppointment,
			TelNumber1,
			TelNumber2,
			CustomerCreationDate,
			CustomerIdTypeId,
			CustomerPhone
		)
		SELECT
			MAX(a.AppointmentId),
			MAX(at.AppointmentTypeId),
			MAX(at.AppointmentTypeName),
			MAX(at.Duration),
			MAX(a.AppointmentDate), --TODO: Cast to appointment hour only
			MAX(c.DateCreated),
			MAX(p.ProcessId),
			MAX(c.CaseId),
			MAX(p.CurrentEntityStatus),
			MAX(CASE WHEN pcd.PropertyKey = 'City' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'Street' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'HouseNumber' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'Summary' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'CustomerName' THEN pcp.Value END),
			MAX(p.RecentNotes),
			MAX(c.CustomerId),
			MAX(cu.PersonalId),
			MAX(cu.FirstName),
			MAX(cu.LastName),
			MAX(CASE WHEN a.AppointmentDate >= CAST(GETDATE() AS DATE) AND p.CurrentEntityStatus = 0 THEN 1 ELSE 0 END),
			MAX(cu.TelNumber1),
			MAX(cu.TelNumber2),
			MAX(CASE WHEN cpd.ExtRef = 'CreationDate' THEN CONVERT(DATETIME, ccp.PropertyValue, 103) END),
			MAX(cu.CustomerIdTypeId),
			MAX(CASE WHEN pcd.PropertyKey = 'CustomerPhone' THEN pcp.Value END)
		FROM qf.AppointmentAll a
		JOIN qf.ProcessAll p ON p.ProcessId = a.ProcessId
		JOIN qf.[CaseAll] c ON c.CaseId = p.CaseId
		LEFT JOIN qf.ProcessCustomPropertyAll pcp ON pcp.ProcessId = p.ProcessId 
		LEFT JOIN qf.ProcessCustomPropertyDictionary pcd ON pcd.PropertyId = pcp.PropertyId
		JOIN qf.[Service] s ON s.ServiceId = a.ServiceId 
		JOIN qf.Users u ON u.UserId = s.CalendarOwnerUserId
		JOIN qf.appointmentType at ON at.AppointmentTypeId = a.AppointmentTypeId
		JOIN qf.Users u2 ON u2.UserId = c.CreatedBy
		JOIN qf.Customer cu ON cu.CustomerId = c.CustomerId
		LEFT JOIN qf.CustomerCustomProperty ccp ON ccp.CustomerId = cu.CustomerId
		LEFT JOIN qf.CustomPropertiesDictionary cpd ON cpd.PropertyId = ccp.PropertyId	
		WHERE   u.UserId = @UserId
			AND CAST(a.AppointmentDate AS DATE) = CAST(@CalendarDate AS DATE)
			AND (p.Resolution IS NULL OR NOT p.Resolution IN (1,5))
		GROUP BY a.AppointmentId, a.AppointmentDate;

		INSERT INTO #AppointmentsTemp
		(
			AppointmentTime,
			IsFutureAppointment,
			Duration,
			[Subject]
		)
		SELECT
			cth.StartDate,
			CASE WHEN cth.StartDate > GETDATE() THEN 1 ELSE 0 END,
			cth.Duration,
			CASE WHEN s.CalendarOwnerUserId = @CurrentUserId THEN cth.[Subject] ELSE @l_SubjectValue END -- DO NOT CHANGE THE RETURN STRING
		FROM qf.CalendarOccupiedTimeAll cth
		JOIN qf.CalendarAll c ON c.ServiceId = cth.ServiceId AND CAST(c.[Date] AS DATE) = CAST(@CalendarDate AS DATE)
		JOIN qf.[Service] s ON s.ServiceId = c.ServiceId
		JOIN qf.Users u ON u.UserId = s.CalendarOwnerUserId AND u.UserId = @UserId;
	END
	ELSE
	BEGIN
		INSERT INTO #AppointmentsTemp
		(
			AppointmentId,
			AppointmentTypeId,
			AppointmentTypeName,
			Duration,
			AppointmentTime,
			AppointmentCreationDate,
			ProcessId,
			CaseId,
			ProcessStatus,
			City,
			Street,
			HouseNumber,
			Summary,
			CustomerName,
			RecentNotes,
			CustomerId,
			PersonalId,
			CustomerFirstName,
			CustomerLastName,
			IsFutureAppointment,
			TelNumber1,
			TelNumber2,
			CustomerCreationDate,
			CustomerIdTypeId,
			CustomerPhone
		)
		SELECT
			MAX(a.AppointmentId),
			MAX(at.AppointmentTypeId),
			MAX(at.AppointmentTypeName),
			MAX(at.Duration),
			MAX(a.AppointmentDate), --TODO: Cast to appointment hour only
			MAX(c.DateCreated),
			MAX(p.ProcessId),
			MAX(c.CaseId),
			MAX(p.CurrentEntityStatus),
			MAX(CASE WHEN pcd.PropertyKey = 'City' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'Street' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'HouseNumber' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'Summary' THEN pcp.Value END),
			MAX(CASE WHEN pcd.PropertyKey = 'CustomerName' THEN pcp.Value END),
			MAX(p.RecentNotes),
			MAX(c.CustomerId),
			MAX(cu.PersonalId),
			MAX(cu.FirstName),
			MAX(cu.LastName),
			MAX(CASE WHEN a.AppointmentDate >= CAST(GETDATE() AS DATE) AND p.CurrentEntityStatus = 0 THEN 1 ELSE 0 END),
			MAX(cu.TelNumber1),
			MAX(cu.TelNumber2),
			MAX(CASE WHEN cpd.ExtRef = 'CreationDate' THEN CONVERT(DATETIME, ccp.PropertyValue, 103) END),
			MAX(cu.CustomerIdTypeId),
			MAX(CASE WHEN pcd.PropertyKey = 'CustomerPhone' THEN pcp.Value END)
		FROM qf.Appointment a
		JOIN qf.Process p ON p.ProcessId = a.ProcessId
		JOIN qf.[Case] c ON c.CaseId = p.CaseId
		LEFT JOIN qf.ProcessCustomProperty pcp ON pcp.ProcessId = p.ProcessId 
		LEFT JOIN qf.ProcessCustomPropertyDictionary pcd ON pcd.PropertyId = pcp.PropertyId
		JOIN qf.[Service] s ON s.ServiceId = a.ServiceId 
		JOIN qf.Users u ON u.UserId = s.CalendarOwnerUserId
		JOIN qf.appointmentType at ON at.AppointmentTypeId = a.AppointmentTypeId
		JOIN qf.Users u2 ON u2.UserId = c.CreatedBy
		JOIN qf.Customer cu ON cu.CustomerId = c.CustomerId
		LEFT JOIN qf.CustomerCustomProperty ccp ON ccp.CustomerId = cu.CustomerId
		LEFT JOIN qf.CustomPropertiesDictionary cpd ON cpd.PropertyId = ccp.PropertyId	
		WHERE   u.UserId = @UserId
			AND CAST(a.AppointmentDate AS DATE) = CAST(@CalendarDate AS DATE)
			AND (p.Resolution IS NULL OR NOT p.Resolution IN (1,5))
		GROUP BY a.AppointmentId, a.AppointmentDate;

		INSERT INTO #AppointmentsTemp
		(
			AppointmentTime,
			IsFutureAppointment,
			Duration,
			[Subject]
		)
		SELECT
			cth.StartDate,
			CASE WHEN cth.StartDate > GETDATE() THEN 1 ELSE 0 END,
			cth.Duration,
			CASE WHEN s.CalendarOwnerUserId = @CurrentUserId THEN cth.[Subject] ELSE @l_SubjectValue END -- DO NOT CHANGE THE RETURN STRING
		FROM qf.CalendarOccupiedTime cth
		JOIN qf.Calendar c ON c.ServiceId = cth.ServiceId AND CAST(c.[Date] AS DATE) = CAST(@CalendarDate AS DATE)
		JOIN qf.[Service] s ON s.ServiceId = c.ServiceId
		JOIN qf.Users u ON u.UserId = s.CalendarOwnerUserId AND u.UserId = @UserId;
	END

	SELECT
		AppointmentId,
		AppointmentTypeId,
		AppointmentTypeName,
		Duration,
		AppointmentTime,
		AppointmentCreationDate,
		ProcessId,
		CaseId,
		ProcessStatus,
		City,
		Street,
		HouseNumber,
		Summary,
		CustomerName,
		RecentNotes,
		CustomerId,
		CustomerFirstName,
		CustomerLastName,
		IsFutureAppointment,
		PersonalId,
		TelNumber1,
		TelNumber2,
		[Subject],
		CustomerCreationDate,
		CustomerIdTypeId,
		CustomerPhone
	FROM #AppointmentsTemp;

END