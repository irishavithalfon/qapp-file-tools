﻿-- =============================================
-- Author:		<Nativ Dadon>
-- Create date: <25/12/2018>
-- Description:	<Get the dates where calendar is active>
-- Old name: [cqf].[BusinessLeadManagementCalendarDatesGetByAppointmentType]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementCalendarDatesGetByAppointmentType]
			 @UserId INT,
			 @AppointmentTypeId int
AS
    BEGIN
        SET NOCOUNT ON;
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

        DECLARE @l_daysForward INT= 60, 
				@l_duration NUMERIC(6, 2), 
				@l_isDefault BIT, 
				@l_appointmentTypeDuration INT= 0;

		DECLARE @l_StartDate date,
				@l_EndDate date,
				@l_timeInMinutes int
			
		SET @l_timeInMinutes = [qf].[GetTimeInMinutes](GETDATE())	

		SET @l_StartDate = CAST(GETDATE() AS DATE)
		SET @l_EndDate = DATEADD(DAY, @l_daysForward, GETDATE())

        --EXEC qf.ContentValueGetByParameterName 'AssociateDays', 
        --											0,
        --										    'en',
        --											@l_daysForward OUT,
        --											@l_duration OUT,
        --											@l_isDefault OUT 



        SELECT DISTINCT 
                c.CalendarId, 
                c.[Date], 
                MIN(cs.StartTime) AS 'StartTime', 
                MAX(cs.EndTime) AS 'EndTime'
        FROM qf.Calendar c
            JOIN qf.CalendarSegment cs ON cs.CalendarId = c.CalendarId
            JOIN qf.[Service] s ON c.ServiceId = s.ServiceId and s.CalendarOwnerUserId = @UserId
			join qf.CalendarSlotSequencePart cssp on cssp.CalendarId = c.CalendarId and cssp.AppointmentTypeId = @AppointmentTypeId
        WHERE c.[Date] BETWEEN @l_StartDate AND @l_EndDate
             AND c.[Status] = 0 
			 and ((c.[Date] = @l_StartDate and (@l_timeInMinutes <= PartStartTime or @l_timeInMinutes + AppointmentTypeDuration <= PartEndTime))
			   or (c.[Date] > @l_StartDate))
        GROUP BY c.CalendarId, c.[Date]

    END;


	-- (cssp.PartStartTime >= @l_timeInMinutes and (@l_timeInMinutes + cssp.AppointmentTypeDuration) <= cssp.PartEndTime)) 