﻿-- =============================================
-- Author:		<Nativ Dadon>
-- Create date: <6/2/2019>
-- Description:	<Returns the first vacancy slot to set an appointment>
-- Old name: [cqf].[BusinessLeadManagementCalendarGetSuggestedSlots]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementCalendarGetSuggestedSlots]
				@UserId INT,
				@Date DATETIME,
				@AppointmentTypeId INT
AS
BEGIN
	
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	DECLARE @l_calendarId INT,
			@l_serviceId INT

	SELECT @l_calendarId = c.CalendarId,
		   @l_serviceId = s.ServiceId
	FROM qf.Calendar c 
	JOIN qf.[Service] s ON s.ServiceId = c.ServiceId
	JOIN qf.Users u ON u.UserId = s.CalendarOwnerUserId AND u.UserId = @UserId
	WHERE CAST(c.[Date] AS DATETIME) = CAST (@Date AS DATETIME)

	CREATE TABLE #Temp 
	(
		StartTime INT,
		AppointmentDuration INT,
		SlotReservationReasonId INT,
		SlotReservationReasonName NVARCHAR(50),
		SlotReservationColorCode BIT,
		LockedByUserId INT,
		AllocatedToServiceId INT,
		[Status] INT,
		FirstOridinalNumber INT,
		Duration INT 
	)

	INSERT INTO #TEMP EXEC qf.CalendarGetDynamicSuggestedSlots @l_calendarId,@UserId,1,0,@AppointmentTypeId,0,0

	UPDATE #Temp
	SET AllocatedToServiceId = @l_serviceId

	SELECT * , StartTime + AppointmentDuration as 'EndTime'
	FROM #Temp 
	WHERE AppointmentDuration > 0


END