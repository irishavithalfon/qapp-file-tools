﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Original Procedure name:	[cqf].[BusinessLeadManagementOrganizationTreeGet]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementOrganizationTreeGet]
	-- Add the parameters for the stored procedure here
	@TopUnitId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT u.UnitName,
			u.UnitId, 
			u.UnitIdPath
	FROM qf.Unit u 
	WHERE ( 
			u.UnitIdPath LIKE CAST(@TopUnitId as varchar(10)) + '.%' OR
			u.UnitIdPath LIKE '%.' + CAST(@TopUnitId as varchar(10)) + '.%' OR
			u.UnitIdPath LIKE '%.' + CAST(@TopUnitId as varchar(10)) OR 
			u.UnitIdPath = CAST(@TopUnitId as varchar(10))
           )
	ORDER BY u.UnitName
END
