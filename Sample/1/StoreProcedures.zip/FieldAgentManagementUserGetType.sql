﻿-- =============================================
-- Author:		Mor Hagbi
-- Create date: 23/12/2018
-- Description:	Get user type by his group
-- Original procedure name: [cqf].[BusinessLeadManagementUserGetType]
-- =============================================
CREATE PROCEDURE [cqf].[FieldAgentManagementUserGetType]
	             @UserName NVARCHAR(250)
AS
BEGIN

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	DECLARE @l_GroupExtref NVARCHAR(200), 
	        @UserType INT
    

	--CREATE TABLE #UserResult(
	
	--UserId      INT, 
	--UserType    INT,	
	--);

    --Get the user group extref
	
    --INSERT INTO #UserResult   	
	SELECT u.UserId,
           CASE WHEN g.ExtRef LIKE '%Manager%' THEN 1 ELSE 0 END AS 'UserType', 
		   g.ExtRef AS 'GroupExtref'
	FROM qf.Users u 
		JOIN qf.Groups g on  u.GroupId = g.GroupId 
	WHERE u.UserName = @UserName


	--SELECT ur.UserId,
	--       ur.UserType
	--FROM #UserResult ur

END
