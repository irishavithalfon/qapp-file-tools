-- =============================================
-- Author:		Barak Josef
-- Create date: 03/05/2017
-- Description:	Get all MbrCode
-- =============================================
CREATE PROCEDURE [cqf].[MbrCodeGetAll]
	@ActiveOnly BIT = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT kod_sherut,
			teur_sherut_ivri,	
			kod_mb_pnimi,			
			'' AS ExtRef,		
			CASE WHEN sw_mevutal = 'כ' THEN 0 ELSE 1 END AS IsActive
	FROM cqf.dmg_shirutim_refuim
	WHERE (@ActiveOnly = 1 AND sw_mevutal <> 'כ')
			OR (@ActiveOnly = 0)

	IF @@ROWCOUNT = 0 RETURN  11; -- Record NOT FOUND
RETURN 0
END
