-- =============================================
-- Author:		Tomer Zaguri
-- Create date:	08/05/2018
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [cqf].[EntityEventLogSave] @EntityId       INT,
                                        @EntityType     [nvarchar](255),
                                        @UserId  INT,
                                        @PreviousEntity XML,
                                        @NewEntity      XML
AS
     BEGIN
         SET NOCOUNT ON;

	    DECLARE @l_UserCreatedId INT, @l_CreationDate DATETIME;

         IF @PreviousEntity IS NOT NULL
             BEGIN
                 SELECT @l_UserCreatedId = UserCreatedId,
                        @l_CreationDate = CreationDate
                 FROM cqf.EntityEventLog
                 WHERE EntityId = @EntityId
                       AND EntityType = @EntityType;
             END;

         INSERT INTO cqf.EntityEventLog
		  (EntityId,
		   EntityType,
		   UserCreatedId,
		   CreationDate,
		   PreviousEntity,
		   UserUpdatedId,
		   UpdateDate,
		   NewEntity
		  )
         VALUES
		  (@EntityId,
		   @EntityType,
		   ISNULL(@l_UserCreatedId, @UserId),
		   ISNULL(@l_CreationDate, GETDATE()),
		   CASE WHEN @l_UserCreatedId IS NULL THEN NULL ELSE @PreviousEntity END,
		   CASE WHEN @l_UserCreatedId IS NULL THEN NULL ELSE @UserId END,
		   CASE WHEN @l_CreationDate IS NULL THEN NULL ELSE GETDATE() END,
		   @NewEntity
		  );

     END;
