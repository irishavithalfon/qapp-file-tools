CREATE PROCEDURE [cqf].[FindInOrgTree]
	@TopUnitId INT,
	@Query NVARCHAR(250),
	@UnitsOnly bit
AS
	SET NOCOUNT ON;

	DECLARE
		@l_RootUnitIdPath VARCHAR(400),
		@l_RootUnitPath NVARCHAR(2000);

	SELECT
		@l_RootUnitIdPath = pu.UnitIdPath + '.',
		@l_RootUnitPath = pu.UnitPath + '\'
	FROM [qf].[Unit] u WITH (NOLOCK) 
	LEFT JOIN [qf].[Unit] pu WITH (NOLOCK) ON u.[ParentUnitId] = pu.[UnitId]
	WHERE u.[UnitId] = @TopUnitId
	
	SELECT @l_RootUnitIdPath = ISNULL(@l_RootUnitIdPath, '')
	SELECT @l_RootUnitPath = ISNULL(@l_RootUnitPath, '')
	
	SELECT 
		res.[ObjectId],
		res.[ObjectName],
		res.[IdPath],
		res.[NamePath],
		res.[ObjectType]
	FROM (
		SELECT u.[UnitId] AS ObjectId,
			   u.[UnitName] AS ObjectName,
			   replace(u.[UnitIdPath], @l_RootUnitIdPath, '') IdPath,
			   replace(u.[UnitPath], @l_RootUnitPath, '') NamePath,
			   'unit' AS ObjectType
		FROM [qf].[Unit] u WITH (NOLOCK)	
		WHERE
			(
				u.[UnitId] = @TopUnitId
				OR u.[UnitIdPath] LIKE (@l_RootUnitIdPath + '%')
			)
			AND u.[UnitName] LIKE ('%' + @Query + '%')
			AND u.[IsActive] = 1

			
		UNION
		
		SELECT s.[ServiceId] AS ObjectId,
			   s.[ServiceName] AS ObjectName,
			   replace(u.[UnitIdPath], @l_RootUnitIdPath, '') + '.' + CAST(s.[ServiceId] AS nvarchar) IdPath,
			   replace(u.[UnitPath], @l_RootUnitPath, '') + '\' + s.[ServiceName] NamePath,
			   'service' AS ObjectType
		FROM [qf].[Service] s WITH (NOLOCK)
			JOIN qf.[Unit] u WITH (NOLOCK) ON s.[UnitId] = u.[UnitId]
			JOIN qf.[ServiceProfile] sp WITH (NOLOCK) ON s.[ServiceProfileId] = sp.[ServiceProfileId]
		WHERE
			@UnitsOnly = 0
			AND (
				u.[UnitId] = @TopUnitId
				OR u.[UnitIdPath] LIKE (@l_RootUnitIdPath + '%')
			)
			AND s.[ServiceName] LIKE ('%' + @Query + '%')
			AND s.[IsActive] = 1
	) as [res]
