-- =============================================
-- Author:		Tomer Zaguri
-- Create date:	21/11/2017
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [cqf].[AppointmentGetInstruction] @ServiceId         INT,
                                              @AppointmentTypeId INT
AS
         BEGIN
             SET NOCOUNT ON;
             DECLARE @duration NUMERIC(6, 2);
             DECLARE @isDefault BIT;
             DECLARE @globalInstruction NVARCHAR(255);
             EXEC qf.ContentValueGetByParameterName
                  'GlobalInstruction',
                  0,
                  'he',
                  @globalInstruction OUTPUT,
                  @duration OUTPUT,
                  @isDefault OUTPUT;
             DECLARE @UnitId INT;
             SELECT @UnitId = UnitId
             FROM qf.[Service]
             WHERE ServiceId = @ServiceId;
             DECLARE @hospitalUnitId INT;
             DECLARE @hospitalInstruction NVARCHAR(255);
             SELECT @hospitalUnitId = UnitId
             FROM cqf.UnitGetHospital(@UnitId);
             EXEC qf.ContentValueGetByParameterName
                  'HospitalCodeInstruction',
                  @hospitalUnitId,
                  'he',
                  @hospitalInstruction OUTPUT,
                  @duration OUTPUT,
                  @isDefault OUTPUT;
             DECLARE @clinicInstruction NVARCHAR(255);
             EXEC qf.ContentValueGetByParameterName
                  'ClinicInstruction',
                  @UnitId,
                  'he',
                  @clinicInstruction OUTPUT,
                  @duration OUTPUT,
                  @isDefault OUTPUT;
             DECLARE @calendarInstruction NVARCHAR(255);
             EXEC qf.ContentValueGetByParameterName
                  'CalendarInstruction',
                  @ServiceId,
                  'he',
                  @calendarInstruction OUTPUT,
                  @duration OUTPUT,
                  @isDefault OUTPUT;
             DECLARE @appointmentTypeInstruction NVARCHAR(255);
             EXEC qf.ContentValueGetByParameterName
                  'Instruction',
                  @AppointmentTypeId,
                  'he',
                  @appointmentTypeInstruction OUTPUT,
                  @duration OUTPUT,
                  @isDefault OUTPUT;
             SELECT @globalInstruction AS GlobalInstruction,
                    @hospitalInstruction AS HospitalInstruction,
                    @clinicInstruction AS ClinicInstruction,
                    @calendarInstruction AS CalendarInstruction,
                    @appointmentTypeInstruction AS AppointmentTypeInstruction;
         END;
