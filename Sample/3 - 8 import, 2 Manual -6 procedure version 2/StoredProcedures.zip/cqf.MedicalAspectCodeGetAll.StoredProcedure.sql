CREATE PROCEDURE [cqf].[MedicalAspectCodeGetAll]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT
		MedicalServiceCode,
		MedicalServiceDesc,
		kod_mb_pnimi,
		mbrCodeId
	FROM
		(
			SELECT  mac.MedicalServiceCode,
					mc.teur_sherut_ivri as MedicalServiceDesc,
					mc.kod_mb_pnimi ,
					mc.kod_sherut as mbrCodeId,
					ROW_NUMBER() over (PARTITION BY mc.kod_sherut ORDER BY mc.kod_sherut DESC) as RowNum
			FROM cqf.dmg_shirutim_refuim mc
				JOIN cqf.dmg_ServicesMedicalAspect mac ON mac.ClalitServiceCode = mc.kod_sherut
			WHERE mc.sw_mevutal <> 'כ'
		) Codes
	WHERE RowNum = 1
END

